# -*- coding: utf-8 -*-

import requests
from odoo import api, fields, models, _
import logging
_logger = logging.getLogger(__name__)

class SaleOrder(models.Model):
	_inherit = "sale.order"

	@api.model
	def create(self, vals):
		if 'company_id' in vals:
			self = self.with_company(vals['company_id'])
		if vals.get('name', _('New')) == _('New'):
			seq_date = None
			if 'date_order' in vals:
				seq_date = fields.Datetime.context_timestamp(self, fields.Datetime.to_datetime(vals['date_order']))
			vals['name'] = self.env['ir.sequence'].next_by_code('sale.order', sequence_date=seq_date) or _('New')

		# Makes sure partner_invoice_id', 'partner_shipping_id' and 'pricelist_id' are defined
		if any(f not in vals for f in ['partner_invoice_id', 'partner_shipping_id', 'pricelist_id']):
			partner = self.env['res.partner'].browse(vals.get('partner_id'))
			addr = partner.address_get(['delivery', 'invoice'])
			vals['partner_invoice_id'] = vals.setdefault('partner_invoice_id', addr['invoice'])
			vals['partner_shipping_id'] = vals.setdefault('partner_shipping_id', addr['delivery'])
			vals['pricelist_id'] = vals.setdefault('pricelist_id', partner.property_product_pricelist.id)
		
		# logging.info("VALOR DE VALS: " + str(vals))
		config_model = self.env['ir.config_parameter'].sudo()
		# url = "https://prod-42.westus.logic.azure.com:443/workflows/87751d86593c449495cb5ebff6f1a876/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=d86mun_4KtfZeGD_nHeAfUe4CRokZIQUmfdYeL_ohBI"

		result = super(SaleOrder, self).create(vals)
		logging.info("VALOR DE RES: " + str(result))
		vals2 = dict(vals)
		vals2["id"] = result
		data = str(vals2).replace("False", "false").replace("True", "true")
		url = config_model.get_param('post.request.url')
		res = requests.post(url, data=data)
		return result
		# super(SaleOrder, self).create(vals)
		
