`3.5.0`
-------

- Added Database Size Route
- Added File Upload Route

`3.4.0`
-------

- Added XMLID Route

`3.3.0`
-------

- Added a rest_debug config option

`3.2.0`
-------

- Added a file_response option to File routes

`3.1.0`
-------

- Added UserInfo route

`3.0.0`
-------

- OAuth1 & OAuth2

`2.0.0`
-------

- Migrated to Python 3

`1.2.0`
-------

- Added Database & File routes

`1.1.0`
-------

- Added report route

`1.0.0`
-------

- Init version
